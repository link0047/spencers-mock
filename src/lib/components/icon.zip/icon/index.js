import Icon from "./Icon.svelte";
export default Icon;